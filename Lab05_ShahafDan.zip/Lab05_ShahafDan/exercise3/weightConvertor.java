import java.util.Scanner;
import java.util.*;
/** Student: Shahaf Dan*/
public class weightConvertor
{
    public static void main(String[] args)
    {
        System.out.println("Kilograms \t Pounds");
        for (int i = 0; i < 200; i++)
        {
            System.out.println(i + " \t " + (2.2*i));
        }
        
    }
}
