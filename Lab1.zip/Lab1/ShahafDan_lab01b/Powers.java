
/**
 * Write a description of class Powers here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Powers
{
    public static void main()
    {
        System.out.println("a\ta^2\ta^3");
        for (int i = 0; i <5; i++)
        {
         
            System.out.println(i + "\t" + i*i + "\t" + i*i*i);
        }
    }
}
