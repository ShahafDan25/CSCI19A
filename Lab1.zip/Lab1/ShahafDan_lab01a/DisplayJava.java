
/** Student: Shahaf Dan */
public class DisplayJava
{
    public static void main(String[] args)
    {
        for (int i = 0; i <7; i++) //executes the code below 7 times
        {
            System.out.println("Welcome to Java"); //prints this
        }
    }
}
