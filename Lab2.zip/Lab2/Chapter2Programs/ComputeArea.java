
/**
 * Student: Shahaf Dan
 */
public class ComputeArea
{
    public static void main(String[] args)
    {
        double radius; //Declare radius
        double area; //Declare Area
        
        //Assign a Radius
        radius = 20; //radius is now 20
        
        //Compure Area
        area = radius * radius * 3.14159;
        
        //Display Results
        System.out.println("The area for the circle of radius " + radius + " is " + area);
    }
    
}
