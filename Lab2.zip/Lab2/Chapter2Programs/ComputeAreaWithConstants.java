import java.util.Scanner; //Scanner is in the java.util package;
/** Student: Shahaf Dan*/
public class ComputeAreaWithConstants
{
    public static void main(String[] args)
    {
        final double PI = 3.14159; //declare a constant
        
        //Create a Scanner object
        Scanner input = new Scanner(System.in);
        
        //prompt the user to enter a radius
        System.out.print ("Enter a number for radius: ");
        double radius = input.nextDouble();
        
        //Compute Area
        double area = radius * radius * PI;
        
        //Display Results
        System.out.println("The Area for the circle of radius " + radius + " is " + area);
         
    }
    
}
