import java.util.Scanner; //Scanner is in the Java.util package
/** Student : Shahaf Dan */
public class ComputeAreaWithControlInput
{
    public static void main (String[] args)
    {
        //Create a Scanner Object
        Scanner input = new Scanner(System.in);
        
        //Prompt the user to enter a radius;
        System.out.println("enter a number for radius: ");
        double radius = input.nextDouble();
        
        //Computer Area
        double area = radius * radius * 3.14159;
        
        //Display Results
        System.out.println("The area for the circle of radius " + radius + " is " + area);
    }
}
