import java.util.Scanner;

/** Student: Shahaf Dan*/
public class ComputeLoan
{
    public static void main(String[] args)
    {
        //Create Scanner
        Scanner input = new Scanner(System.in);
        
        //Enter the annual ineterst rate in percentage, e.g. 7.25
        System.out.println("Enter the annual ineterst rate");
        double annualInterestRate = input.nextDouble();
        
        //Obtain monthly ineterst rate
        double monthlyInterestRate = annualInterestRate / 1200;
        
        //Enter number of years
        System.out.print("Enter number of years as an integer");
        int numberOfYears = input.nextInt();
        
        //enter loan amount
        System.out.print("Enter loan amount ");
        double loanAmount = input.nextDouble();
        
        //calculate payment
        double monthlyPayment = loanAmount * monthlyInterestRate / (1 - 1/ Math.pow(1 + monthlyInterestRate, numberOfYears * 12));
        double totalPayment = monthlyPayment * numberOfYears * 12;
        
        //Display results
        System.out.println("The monthly payment is $ " + (int)(monthlyPayment*100) / 100.0);
        System.out.println("The total payment is $ " + (int)(totalPayment * 100) / 100.0);
    }
}
