import java.util.Scanner; //Scanner is in the java.util package
/** Student: Shahaf Dan */
public class ComputeAverage
{
    public static void main(String[] args)
    {
        //Create a Scanner object
        Scanner input = new Scanner(System.in);
        
        //Prompt the user to enter three numbers;
        System.out.println("Enter Three Numbers: ");
        double number1 = input.nextDouble();
        double number2 = input.nextDouble();
        double number3 = input.nextDouble();
        
        //Compute Average
        double average = (number1 + number2 + number3) / 3;
        
        //Display results
        System.out.println("The Average of " + number1 + ", " + number2 + ", " + number3 + " is: " + average);
        
    }
    
}
